from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.UserParam import UserSettableParameter
from model import PerceptronModel

def perceptron_portrayal(agent):
    return {"Shape": "circle", "Color": "blue", "r": 0.5}

model_params = {
    "learning_rate": UserSettableParameter("slider", "Learning Rate", 0.1, 0.01, 1.0, 0.01),
    "iterations": UserSettableParameter("slider", "Iterations", 10, 1, 100, 1)
}

server = ModularServer(
    PerceptronModel,
    [CanvasGrid(perceptron_portrayal, 10, 10, 500, 500)],
    "Perceptron Simulation",
    model_params
)

server.port = 8521
server.launch()

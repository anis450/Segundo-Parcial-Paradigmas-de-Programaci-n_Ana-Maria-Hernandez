from mesa import Model
from mesa.time import BaseScheduler
from agent import PerceptronAgent
import random

class PerceptronModel(Model):
    def __init__(self, learning_rate, iterations, num_points=100):
        self.schedule = BaseScheduler(self)
        self.agent = PerceptronAgent(0, self)
        self.schedule.add(self.agent)
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.points = self.generate_points(num_points)
        self.current_iter = 0

    def generate_points(self, num_points):
        data = []
        for _ in range(num_points):
            x = [random.uniform(-1, 1), random.uniform(-1, 1)]
            label = 1 if x[0] + x[1] > 0 else -1
            data.append((x, label))
        return data

    def step(self):
        if self.current_iter < self.iterations:
            for x, y in self.points:
                self.agent.train(x, y, self.learning_rate)
            self.current_iter += 1

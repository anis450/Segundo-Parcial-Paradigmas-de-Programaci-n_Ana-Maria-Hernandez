from mesa import Agent

class PerceptronAgent(Agent):
    def __init__(self, unique_id, model):
        super().__init__(unique_id, model)
        self.weights = [self.random.uniform(-1, 1) for _ in range(2)]
        self.bias = self.random.uniform(-1, 1)

    def predict(self, x):
        activation = sum(w * xi for w, xi in zip(self.weights, x)) + self.bias
        return 1 if activation >= 0 else -1

    def train(self, x, y_true, learning_rate):
        y_pred = self.predict(x)
        error = y_true - y_pred
        for i in range(2):
            self.weights[i] += learning_rate * error * x[i]
        self.bias += learning_rate * error

from mesa import Agent

class OperationAgent(Agent):
    def __init__(self, unique_id, model, operation):
        super().__init__(unique_id, model)
        self.operation = operation

    def compute(self, a, b):
        if self.operation == '+': return a + b
        if self.operation == '-': return a - b
        if self.operation == '*': return a * b
        if self.operation == '/': return a / b if b != 0 else 'Error'
        if self.operation == '^': return a ** b

from mesa import Model
from mesa.time import BaseScheduler
from agent import OperationAgent

class CalculatorModel(Model):
    def __init__(self, expression):
        self.schedule = BaseScheduler(self)
        self.expression = expression
        self.result = None
        self.agents = {
            '+': OperationAgent(1, self, '+'),
            '-': OperationAgent(2, self, '-'),
            '*': OperationAgent(3, self, '*'),
            '/': OperationAgent(4, self, '/'),
            '^': OperationAgent(5, self, '^')
        }

    def parse_expression(self):
        tokens = self.expression.split()
        return tokens

    def step(self):
        tokens = self.parse_expression()
        a, op, b = float(tokens[0]), tokens[1], float(tokens[2])
        self.result = self.agents[op].compute(a, b)

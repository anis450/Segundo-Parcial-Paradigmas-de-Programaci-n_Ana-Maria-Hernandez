from model import CalculatorModel

modelo = CalculatorModel('2 + 3')
modelo.step()
print('Resultado:', modelo.result)

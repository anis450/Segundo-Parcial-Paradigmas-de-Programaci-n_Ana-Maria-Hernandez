import kotlin.math.*

class CalculadoraCientifica : Calculadora() {
    fun seno(x: Double) = sin(x)
    fun coseno(x: Double) = cos(x)
    fun tangente(x: Double) = tan(x)
    fun log10(x: Double) = log10(x)
    fun loge(x: Double) = ln(x)
    fun exp(x: Double) = exp(x)
    fun raiz(x: Double) = sqrt(x)
    fun gradosARadianes(x: Double) = Math.toRadians(x)
    fun radianesAGrados(x: Double) = Math.toDegrees(x)
}
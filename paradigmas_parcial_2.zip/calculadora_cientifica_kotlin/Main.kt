fun main() {
    val calc = CalculadoraCientifica()
    println("Suma: " + calc.sumar(2.0, 3.0))
    println("Seno(45°): " + calc.seno(Math.toRadians(45.0)))
}